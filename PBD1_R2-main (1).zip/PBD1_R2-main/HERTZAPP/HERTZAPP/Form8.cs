﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HERTZAPP
{
    public partial class FRMReserva : Form
    {
        public FRMReserva()
        {
            InitializeComponent();
        }

        private void BTNCliente_Click(object sender, EventArgs e)
        {
           
        }

        private void FRMReserva_Load(object sender, EventArgs e)
        {

        }
    }
}
